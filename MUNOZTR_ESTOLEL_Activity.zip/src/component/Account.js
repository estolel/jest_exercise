import React, {Component} from "react";
import { Box, Typography } from "@material-ui/core";
import CheckboxWithLabel from './CheckboxWithLabel.js';


export class Account extends Component{
    constructor(props){
        super(props)
        this.state = {
            isChecked: false
        }
    }

    onClickCheckboxWithLabel(isChecked){
        const {user, moveUser} = this.props;
        moveUser(user, isChecked)
        // moveUser(user, isChecked)
    }

    render(){
        const {user} = this.props

        return(
            <div key = {user.username}>
                <Box justifyContent="center" border={1} style={{width:300}}>
                    <div style={{padding: 10}}>
                        <Typography className='name'>Name: {user.name}</Typography>
                        <Typography className='email'>E-mail Address: {user.email}</Typography>
                        <CheckboxWithLabel 
                            onClickCheckboxWithLabel={this.onClickCheckboxWithLabel.bind(this)} 
                            labelOn={user.username + " is an active User"}
                            labelOff={user.username + " is an inactive User"}/>
                    </div>
                </Box>
            </div>
        )

    }
}


export default Account;